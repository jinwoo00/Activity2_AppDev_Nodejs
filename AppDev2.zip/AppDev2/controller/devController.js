const web ={
    app:(req, res)=>{
        res.render('home');
    }
    //shop:(req, res) => {
        //res.render('shop');
    //},
    //register: (req, res) => {
        //res.render('register');
    //},
    //cart: (req, res) => {
        //res.render('cart');
    //},
    //shop: (req, res) => {
        //res.render('shop');
    //}
};   
module.exports = web;